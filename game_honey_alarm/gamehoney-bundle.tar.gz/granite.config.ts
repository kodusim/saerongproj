import { defineConfig } from '@apps-in-toss/web-framework/config';

export default defineConfig({
  appName: 'gamehoney',
  web: {
    host: 'localhost',
    port: 5173,
    commands: {
      dev: 'vite --host',
      build: 'vite build',
    },
  },
  permissions: [
    'appLogin',
    'pushNotification',
  ],
  outdir: 'dist',
  brand: {
    displayName: 'Game Honey',
    description: '좋아하는 게임의 소식을 알림으로 받아보세요',
    icon: 'https://via.placeholder.com/512x512.png?text=GH',
    primaryColor: '#FFB800',
    bridgeColorMode: 'basic',
  },
});
